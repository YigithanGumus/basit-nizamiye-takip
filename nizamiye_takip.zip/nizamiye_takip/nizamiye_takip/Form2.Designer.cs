﻿namespace nizamiye_takip
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtrutbe = new System.Windows.Forms.TextBox();
            this.lbluyar = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblseviye = new System.Windows.Forms.Label();
            this.lblskor = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.btnformtemizle = new System.Windows.Forms.Button();
            this.btnsil = new System.Windows.Forms.Button();
            this.btnara = new System.Windows.Forms.Button();
            this.btnguncelle = new System.Windows.Forms.Button();
            this.btnkaydet = new System.Windows.Forms.Button();
            this.txtsfrtkr = new System.Windows.Forms.TextBox();
            this.txtsfr = new System.Windows.Forms.TextBox();
            this.txtkull = new System.Windows.Forms.TextBox();
            this.rdbkull = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.rdbyet = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.txtsoyad = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtad = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txttc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtrutbe2 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtmaas = new System.Windows.Forms.MaskedTextBox();
            this.txtsoyad2 = new System.Windows.Forms.MaskedTextBox();
            this.txtad2 = new System.Windows.Forms.MaskedTextBox();
            this.txttc2 = new System.Windows.Forms.MaskedTextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.btnsil2 = new System.Windows.Forms.Button();
            this.btntemizle2 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnguncelle2 = new System.Windows.Forms.Button();
            this.btnkaydet2 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.cbogorevyeri = new System.Windows.Forms.ComboBox();
            this.cbogorev = new System.Windows.Forms.ComboBox();
            this.cbomezuniyet = new System.Windows.Forms.ComboBox();
            this.rdbkadin = new System.Windows.Forms.RadioButton();
            this.rdberkek = new System.Windows.Forms.RadioButton();
            this.btnara2 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btngozat = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblaktif = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.btncikis2 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.btngirisedon = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(252, 11);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1169, 605);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage1.Controls.Add(this.txtrutbe);
            this.tabPage1.Controls.Add(this.lbluyar);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.lblseviye);
            this.tabPage1.Controls.Add(this.lblskor);
            this.tabPage1.Controls.Add(this.progressBar1);
            this.tabPage1.Controls.Add(this.btnformtemizle);
            this.tabPage1.Controls.Add(this.btnsil);
            this.tabPage1.Controls.Add(this.btnara);
            this.tabPage1.Controls.Add(this.btnguncelle);
            this.tabPage1.Controls.Add(this.btnkaydet);
            this.tabPage1.Controls.Add(this.txtsfrtkr);
            this.tabPage1.Controls.Add(this.txtsfr);
            this.tabPage1.Controls.Add(this.txtkull);
            this.tabPage1.Controls.Add(this.rdbkull);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.rdbyet);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.txtsoyad);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.txtad);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txttc);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(1161, 576);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Kullanıcı İşlemleri";
            // 
            // txtrutbe
            // 
            this.txtrutbe.Location = new System.Drawing.Point(187, 105);
            this.txtrutbe.Margin = new System.Windows.Forms.Padding(4);
            this.txtrutbe.Name = "txtrutbe";
            this.txtrutbe.Size = new System.Drawing.Size(100, 22);
            this.txtrutbe.TabIndex = 14;
            // 
            // lbluyar
            // 
            this.lbluyar.AutoSize = true;
            this.lbluyar.Location = new System.Drawing.Point(443, 210);
            this.lbluyar.Name = "lbluyar";
            this.lbluyar.Size = new System.Drawing.Size(0, 16);
            this.lbluyar.TabIndex = 13;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.Location = new System.Drawing.Point(353, 210);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(99, 16);
            this.label18.TabIndex = 12;
            this.label18.Text = "Parola Kriteri";
            // 
            // lblseviye
            // 
            this.lblseviye.AutoSize = true;
            this.lblseviye.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblseviye.Location = new System.Drawing.Point(428, 263);
            this.lblseviye.Name = "lblseviye";
            this.lblseviye.Size = new System.Drawing.Size(54, 16);
            this.lblseviye.TabIndex = 11;
            this.lblseviye.Text = "Seviye";
            // 
            // lblskor
            // 
            this.lblskor.AutoSize = true;
            this.lblskor.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblskor.Location = new System.Drawing.Point(376, 263);
            this.lblskor.Name = "lblskor";
            this.lblskor.Size = new System.Drawing.Size(39, 16);
            this.lblskor.TabIndex = 11;
            this.lblskor.Text = "Skor";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(357, 263);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(179, 34);
            this.progressBar1.TabIndex = 10;
            // 
            // btnformtemizle
            // 
            this.btnformtemizle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnformtemizle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnformtemizle.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnformtemizle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnformtemizle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnformtemizle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnformtemizle.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnformtemizle.ForeColor = System.Drawing.Color.White;
            this.btnformtemizle.Location = new System.Drawing.Point(191, 304);
            this.btnformtemizle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnformtemizle.Name = "btnformtemizle";
            this.btnformtemizle.Size = new System.Drawing.Size(135, 34);
            this.btnformtemizle.TabIndex = 9;
            this.btnformtemizle.Text = "Temizle";
            this.btnformtemizle.UseVisualStyleBackColor = false;
            this.btnformtemizle.Click += new System.EventHandler(this.btnformtemizle_Click);
            // 
            // btnsil
            // 
            this.btnsil.BackColor = System.Drawing.Color.Red;
            this.btnsil.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnsil.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnsil.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnsil.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnsil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsil.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnsil.ForeColor = System.Drawing.Color.White;
            this.btnsil.Location = new System.Drawing.Point(60, 304);
            this.btnsil.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnsil.Name = "btnsil";
            this.btnsil.Size = new System.Drawing.Size(117, 34);
            this.btnsil.TabIndex = 9;
            this.btnsil.Text = "Sil";
            this.btnsil.UseVisualStyleBackColor = false;
            this.btnsil.Click += new System.EventHandler(this.btnsil_Click);
            // 
            // btnara
            // 
            this.btnara.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnara.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnara.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnara.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnara.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnara.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnara.Location = new System.Drawing.Point(312, 17);
            this.btnara.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnara.Name = "btnara";
            this.btnara.Size = new System.Drawing.Size(108, 34);
            this.btnara.TabIndex = 9;
            this.btnara.Text = "Ara";
            this.btnara.UseVisualStyleBackColor = true;
            this.btnara.Click += new System.EventHandler(this.btnara_Click);
            // 
            // btnguncelle
            // 
            this.btnguncelle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnguncelle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnguncelle.FlatAppearance.BorderColor = System.Drawing.Color.Teal;
            this.btnguncelle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.btnguncelle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.btnguncelle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnguncelle.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnguncelle.ForeColor = System.Drawing.Color.White;
            this.btnguncelle.Location = new System.Drawing.Point(191, 263);
            this.btnguncelle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnguncelle.Name = "btnguncelle";
            this.btnguncelle.Size = new System.Drawing.Size(135, 34);
            this.btnguncelle.TabIndex = 9;
            this.btnguncelle.Text = "Güncelle";
            this.btnguncelle.UseVisualStyleBackColor = false;
            this.btnguncelle.Click += new System.EventHandler(this.btnguncelle_Click);
            // 
            // btnkaydet
            // 
            this.btnkaydet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnkaydet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnkaydet.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.btnkaydet.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green;
            this.btnkaydet.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
            this.btnkaydet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnkaydet.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnkaydet.ForeColor = System.Drawing.Color.White;
            this.btnkaydet.Location = new System.Drawing.Point(60, 263);
            this.btnkaydet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnkaydet.Name = "btnkaydet";
            this.btnkaydet.Size = new System.Drawing.Size(117, 34);
            this.btnkaydet.TabIndex = 9;
            this.btnkaydet.Text = "Kaydet";
            this.btnkaydet.UseVisualStyleBackColor = false;
            this.btnkaydet.Click += new System.EventHandler(this.btnkaydet_Click);
            // 
            // txtsfrtkr
            // 
            this.txtsfrtkr.Location = new System.Drawing.Point(187, 222);
            this.txtsfrtkr.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtsfrtkr.Name = "txtsfrtkr";
            this.txtsfrtkr.Size = new System.Drawing.Size(100, 22);
            this.txtsfrtkr.TabIndex = 8;
            this.txtsfrtkr.TextChanged += new System.EventHandler(this.txtsfrtkr_TextChanged);
            // 
            // txtsfr
            // 
            this.txtsfr.Location = new System.Drawing.Point(187, 193);
            this.txtsfr.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtsfr.Name = "txtsfr";
            this.txtsfr.Size = new System.Drawing.Size(100, 22);
            this.txtsfr.TabIndex = 8;
            this.txtsfr.TextChanged += new System.EventHandler(this.txtsfr_TextChanged);
            this.txtsfr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsfr_KeyPress);
            // 
            // txtkull
            // 
            this.txtkull.Location = new System.Drawing.Point(187, 165);
            this.txtkull.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtkull.Name = "txtkull";
            this.txtkull.Size = new System.Drawing.Size(100, 22);
            this.txtkull.TabIndex = 8;
            this.txtkull.TextChanged += new System.EventHandler(this.txtkull_TextChanged);
            this.txtkull.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtkull_KeyPress);
            // 
            // rdbkull
            // 
            this.rdbkull.AutoSize = true;
            this.rdbkull.Location = new System.Drawing.Point(268, 137);
            this.rdbkull.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdbkull.Name = "rdbkull";
            this.rdbkull.Size = new System.Drawing.Size(77, 20);
            this.rdbkull.TabIndex = 7;
            this.rdbkull.TabStop = true;
            this.rdbkull.Text = "Kullanıcı";
            this.rdbkull.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(83, 223);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 16);
            this.label8.TabIndex = 5;
            this.label8.Text = "Parola Tekrar";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // rdbyet
            // 
            this.rdbyet.AutoSize = true;
            this.rdbyet.Location = new System.Drawing.Point(187, 137);
            this.rdbyet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdbyet.Name = "rdbyet";
            this.rdbyet.Size = new System.Drawing.Size(76, 20);
            this.rdbyet.TabIndex = 7;
            this.rdbyet.TabStop = true;
            this.rdbyet.Text = "Yönetici";
            this.rdbyet.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(119, 193);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 16);
            this.label7.TabIndex = 5;
            this.label7.Text = "Parola:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtsoyad
            // 
            this.txtsoyad.Location = new System.Drawing.Point(187, 74);
            this.txtsoyad.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtsoyad.Name = "txtsoyad";
            this.txtsoyad.Size = new System.Drawing.Size(100, 22);
            this.txtsoyad.TabIndex = 6;
            this.txtsoyad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsoyad_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(80, 165);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Kullanıcı Adı:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(136, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Yetki:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.Location = new System.Drawing.Point(127, 108);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 16);
            this.label19.TabIndex = 5;
            this.label19.Text = "Rütbe:  ";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(127, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Soyadı:  ";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtad
            // 
            this.txtad.Location = new System.Drawing.Point(187, 46);
            this.txtad.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtad.Name = "txtad";
            this.txtad.Size = new System.Drawing.Size(100, 22);
            this.txtad.TabIndex = 6;
            this.txtad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtad_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(140, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Adı:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txttc
            // 
            this.txttc.Location = new System.Drawing.Point(187, 17);
            this.txttc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txttc.MaxLength = 11;
            this.txttc.Name = "txttc";
            this.txttc.Size = new System.Drawing.Size(100, 22);
            this.txttc.TabIndex = 6;
            this.txttc.TextChanged += new System.EventHandler(this.txttc_TextChanged);
            this.txttc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txttc_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(25, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "TC kimlik Numarası:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(7, 358);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1164, 202);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage2.Controls.Add(this.txtrutbe2);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.txtmaas);
            this.tabPage2.Controls.Add(this.txtsoyad2);
            this.tabPage2.Controls.Add(this.txtad2);
            this.tabPage2.Controls.Add(this.txttc2);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.btnsil2);
            this.tabPage2.Controls.Add(this.btntemizle2);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.btnguncelle2);
            this.tabPage2.Controls.Add(this.btnkaydet2);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.dateTimePicker1);
            this.tabPage2.Controls.Add(this.cbogorevyeri);
            this.tabPage2.Controls.Add(this.cbogorev);
            this.tabPage2.Controls.Add(this.cbomezuniyet);
            this.tabPage2.Controls.Add(this.rdbkadin);
            this.tabPage2.Controls.Add(this.rdberkek);
            this.tabPage2.Controls.Add(this.btnara2);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.btngozat);
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Size = new System.Drawing.Size(1161, 576);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Yetkili İşlemleri";
            // 
            // txtrutbe2
            // 
            this.txtrutbe2.Location = new System.Drawing.Point(435, 290);
            this.txtrutbe2.Name = "txtrutbe2";
            this.txtrutbe2.Size = new System.Drawing.Size(145, 22);
            this.txtrutbe2.TabIndex = 16;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(379, 290);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(43, 16);
            this.label20.TabIndex = 15;
            this.label20.Text = "Rütbe";
            // 
            // txtmaas
            // 
            this.txtmaas.Location = new System.Drawing.Point(435, 254);
            this.txtmaas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtmaas.Name = "txtmaas";
            this.txtmaas.Size = new System.Drawing.Size(145, 22);
            this.txtmaas.TabIndex = 14;
            // 
            // txtsoyad2
            // 
            this.txtsoyad2.Location = new System.Drawing.Point(107, 244);
            this.txtsoyad2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtsoyad2.Name = "txtsoyad2";
            this.txtsoyad2.Size = new System.Drawing.Size(191, 22);
            this.txtsoyad2.TabIndex = 13;
            // 
            // txtad2
            // 
            this.txtad2.Location = new System.Drawing.Point(107, 217);
            this.txtad2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtad2.Name = "txtad2";
            this.txtad2.Size = new System.Drawing.Size(191, 22);
            this.txtad2.TabIndex = 12;
            // 
            // txttc2
            // 
            this.txttc2.Location = new System.Drawing.Point(107, 188);
            this.txttc2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txttc2.Name = "txttc2";
            this.txttc2.Size = new System.Drawing.Size(89, 22);
            this.txttc2.TabIndex = 11;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Red;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button3.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(767, 224);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(147, 31);
            this.button3.TabIndex = 10;
            this.button3.Text = "Sil";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnsil2
            // 
            this.btnsil2.Location = new System.Drawing.Point(767, 224);
            this.btnsil2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnsil2.Name = "btnsil2";
            this.btnsil2.Size = new System.Drawing.Size(147, 31);
            this.btnsil2.TabIndex = 10;
            this.btnsil2.Text = "Sil";
            this.btnsil2.UseVisualStyleBackColor = true;
            // 
            // btntemizle2
            // 
            this.btntemizle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btntemizle2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btntemizle2.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btntemizle2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btntemizle2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btntemizle2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btntemizle2.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btntemizle2.ForeColor = System.Drawing.Color.White;
            this.btntemizle2.Location = new System.Drawing.Point(615, 224);
            this.btntemizle2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btntemizle2.Name = "btntemizle2";
            this.btntemizle2.Size = new System.Drawing.Size(147, 31);
            this.btntemizle2.TabIndex = 10;
            this.btntemizle2.Text = "Temizle";
            this.btntemizle2.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Teal;
            this.button2.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(767, 185);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(147, 33);
            this.button2.TabIndex = 10;
            this.button2.Text = "Güncelle";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnguncelle2
            // 
            this.btnguncelle2.Location = new System.Drawing.Point(767, 185);
            this.btnguncelle2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnguncelle2.Name = "btnguncelle2";
            this.btnguncelle2.Size = new System.Drawing.Size(147, 33);
            this.btnguncelle2.TabIndex = 10;
            this.btnguncelle2.Text = "Güncelle";
            this.btnguncelle2.UseVisualStyleBackColor = true;
            // 
            // btnkaydet2
            // 
            this.btnkaydet2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnkaydet2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnkaydet2.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnkaydet2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnkaydet2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnkaydet2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnkaydet2.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnkaydet2.ForeColor = System.Drawing.Color.White;
            this.btnkaydet2.Location = new System.Drawing.Point(615, 185);
            this.btnkaydet2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnkaydet2.Name = "btnkaydet2";
            this.btnkaydet2.Size = new System.Drawing.Size(147, 33);
            this.btnkaydet2.TabIndex = 10;
            this.btnkaydet2.Text = "Kaydet";
            this.btnkaydet2.UseVisualStyleBackColor = false;
            this.btnkaydet2.Click += new System.EventHandler(this.btnkaydet2_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(379, 254);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 16);
            this.label17.TabIndex = 9;
            this.label17.Text = "Maaş";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(107, 343);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(187, 22);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // cbogorevyeri
            // 
            this.cbogorevyeri.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbogorevyeri.FormattingEnabled = true;
            this.cbogorevyeri.Location = new System.Drawing.Point(435, 217);
            this.cbogorevyeri.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbogorevyeri.Name = "cbogorevyeri";
            this.cbogorevyeri.Size = new System.Drawing.Size(145, 24);
            this.cbogorevyeri.TabIndex = 7;
            // 
            // cbogorev
            // 
            this.cbogorev.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbogorev.FormattingEnabled = true;
            this.cbogorev.Location = new System.Drawing.Point(435, 185);
            this.cbogorev.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbogorev.Name = "cbogorev";
            this.cbogorev.Size = new System.Drawing.Size(145, 24);
            this.cbogorev.TabIndex = 7;
            // 
            // cbomezuniyet
            // 
            this.cbomezuniyet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbomezuniyet.FormattingEnabled = true;
            this.cbomezuniyet.Location = new System.Drawing.Point(107, 308);
            this.cbomezuniyet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbomezuniyet.Name = "cbomezuniyet";
            this.cbomezuniyet.Size = new System.Drawing.Size(191, 24);
            this.cbomezuniyet.TabIndex = 7;
            // 
            // rdbkadin
            // 
            this.rdbkadin.AutoSize = true;
            this.rdbkadin.Location = new System.Drawing.Point(179, 278);
            this.rdbkadin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdbkadin.Name = "rdbkadin";
            this.rdbkadin.Size = new System.Drawing.Size(62, 20);
            this.rdbkadin.TabIndex = 6;
            this.rdbkadin.TabStop = true;
            this.rdbkadin.Text = "Kadın";
            this.rdbkadin.UseVisualStyleBackColor = true;
            // 
            // rdberkek
            // 
            this.rdberkek.AutoSize = true;
            this.rdberkek.Location = new System.Drawing.Point(107, 278);
            this.rdberkek.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdberkek.Name = "rdberkek";
            this.rdberkek.Size = new System.Drawing.Size(63, 20);
            this.rdberkek.TabIndex = 6;
            this.rdberkek.TabStop = true;
            this.rdberkek.Text = "Erkek";
            this.rdberkek.UseVisualStyleBackColor = true;
            // 
            // btnara2
            // 
            this.btnara2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnara2.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnara2.Location = new System.Drawing.Point(203, 185);
            this.btnara2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnara2.Name = "btnara2";
            this.btnara2.Size = new System.Drawing.Size(95, 27);
            this.btnara2.TabIndex = 5;
            this.btnara2.Text = "Ara";
            this.btnara2.UseVisualStyleBackColor = true;
            this.btnara2.Click += new System.EventHandler(this.btnara2_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(4, 384);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(1169, 175);
            this.dataGridView2.TabIndex = 3;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 346);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(88, 16);
            this.label14.TabIndex = 2;
            this.label14.Text = "Doğum Tarihi";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 313);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 16);
            this.label13.TabIndex = 2;
            this.label13.Text = "Mezuniyeti";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 282);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 16);
            this.label12.TabIndex = 2;
            this.label12.Text = "Cinsiyet";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(16, 250);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 16);
            this.label11.TabIndex = 2;
            this.label11.Text = "Soyadı";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(357, 219);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 16);
            this.label16.TabIndex = 2;
            this.label16.Text = "Görev Yeri";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(16, 222);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(27, 16);
            this.label10.TabIndex = 2;
            this.label10.Text = "Adı";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(381, 188);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 16);
            this.label15.TabIndex = 2;
            this.label15.Text = "Görevi";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 188);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 16);
            this.label9.TabIndex = 2;
            this.label9.Text = "TC Kimlik No";
            // 
            // btngozat
            // 
            this.btngozat.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btngozat.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btngozat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btngozat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btngozat.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btngozat.Location = new System.Drawing.Point(179, 22);
            this.btngozat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btngozat.Name = "btngozat";
            this.btngozat.Size = new System.Drawing.Size(87, 33);
            this.btngozat.TabIndex = 1;
            this.btngozat.Text = "Gözat";
            this.btngozat.UseVisualStyleBackColor = true;
            this.btngozat.Click += new System.EventHandler(this.btngozat_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(19, 22);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(139, 148);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(39, 28);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(149, 150);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(61, 201);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Hoşgeldiniz,";
            // 
            // lblaktif
            // 
            this.lblaktif.AutoSize = true;
            this.lblaktif.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblaktif.Location = new System.Drawing.Point(61, 233);
            this.lblaktif.Name = "lblaktif";
            this.lblaktif.Size = new System.Drawing.Size(53, 20);
            this.lblaktif.TabIndex = 3;
            this.lblaktif.Text = "label2";
            this.lblaktif.Click += new System.EventHandler(this.lblaktif_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // btncikis2
            // 
            this.btncikis2.BackColor = System.Drawing.Color.Red;
            this.btncikis2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btncikis2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btncikis2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btncikis2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncikis2.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btncikis2.ForeColor = System.Drawing.Color.White;
            this.btncikis2.Location = new System.Drawing.Point(39, 571);
            this.btncikis2.Margin = new System.Windows.Forms.Padding(4);
            this.btncikis2.Name = "btncikis2";
            this.btncikis2.Size = new System.Drawing.Size(184, 28);
            this.btncikis2.TabIndex = 5;
            this.btncikis2.Text = "Çıkış";
            this.btncikis2.UseVisualStyleBackColor = false;
            this.btncikis2.Click += new System.EventHandler(this.btncikis2_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Silah Stok Takip",
            "Araç Giriş/Çıkış"});
            this.comboBox1.Location = new System.Drawing.Point(21, 320);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(202, 24);
            this.comboBox1.TabIndex = 8;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(18, 273);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(205, 16);
            this.label21.TabIndex = 9;
            this.label21.Text = "Lütfen gideceğiniz diğer sayfaları ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(62, 289);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(104, 16);
            this.label22.TabIndex = 9;
            this.label22.Text = "buradan seçiniz!";
            // 
            // btngirisedon
            // 
            this.btngirisedon.BackColor = System.Drawing.Color.Red;
            this.btngirisedon.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btngirisedon.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btngirisedon.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btngirisedon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btngirisedon.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btngirisedon.ForeColor = System.Drawing.Color.White;
            this.btngirisedon.Location = new System.Drawing.Point(39, 534);
            this.btngirisedon.Name = "btngirisedon";
            this.btngirisedon.Size = new System.Drawing.Size(184, 30);
            this.btngirisedon.TabIndex = 10;
            this.btngirisedon.Text = "Giriş Ekranına Dön";
            this.btngirisedon.UseVisualStyleBackColor = false;
            this.btngirisedon.Click += new System.EventHandler(this.btngirisedon_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1426, 617);
            this.Controls.Add(this.btngirisedon);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btncikis2);
            this.Controls.Add(this.lblaktif);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtsfrtkr;
        private System.Windows.Forms.TextBox txtsfr;
        private System.Windows.Forms.TextBox txtkull;
        private System.Windows.Forms.RadioButton rdbkull;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton rdbyet;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtsoyad;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtad;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txttc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblaktif;
        private System.Windows.Forms.Label lblseviye;
        private System.Windows.Forms.Label lblskor;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button btnformtemizle;
        private System.Windows.Forms.Button btnsil;
        private System.Windows.Forms.Button btnguncelle;
        private System.Windows.Forms.Button btnkaydet;
        private System.Windows.Forms.Button btnara;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button btnara2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btngozat;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.RadioButton rdberkek;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox cbogorevyeri;
        private System.Windows.Forms.ComboBox cbogorev;
        private System.Windows.Forms.ComboBox cbomezuniyet;
        private System.Windows.Forms.RadioButton rdbkadin;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnsil2;
        private System.Windows.Forms.Button btnkaydet2;
        private System.Windows.Forms.Button btntemizle2;
        private System.Windows.Forms.Button btnguncelle2;
        private System.Windows.Forms.Label lbluyar;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.MaskedTextBox txtsoyad2;
        private System.Windows.Forms.MaskedTextBox txtad2;
        private System.Windows.Forms.MaskedTextBox txttc2;
        private System.Windows.Forms.MaskedTextBox txtmaas;
        private System.Windows.Forms.TextBox txtrutbe;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btncikis2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtrutbe2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btngirisedon;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
    }
}