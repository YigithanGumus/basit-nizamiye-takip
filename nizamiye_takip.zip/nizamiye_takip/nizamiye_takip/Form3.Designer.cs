﻿namespace nizamiye_takip
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblisim = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnara = new System.Windows.Forms.Button();
            this.lblad = new System.Windows.Forms.Label();
            this.lblsoyad = new System.Windows.Forms.Label();
            this.lblcinsiyet = new System.Windows.Forms.Label();
            this.lblmezuniyet = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbldgmtrh = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblgorev = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblmaas = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblgrvyri = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblaktifkull = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.lblrtb = new System.Windows.Forms.Label();
            this.txttc = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(899, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(198, 148);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblisim
            // 
            this.lblisim.AutoSize = true;
            this.lblisim.Location = new System.Drawing.Point(216, 12);
            this.lblisim.Name = "lblisim";
            this.lblisim.Size = new System.Drawing.Size(127, 16);
            this.lblisim.TabIndex = 1;
            this.lblisim.Text = "TC Kimlik Numarası:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(310, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Adı:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(287, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Soyadı:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(280, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Cinsiyeti:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(267, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Mezuniyeti:";
            // 
            // btnara
            // 
            this.btnara.Location = new System.Drawing.Point(455, 12);
            this.btnara.Name = "btnara";
            this.btnara.Size = new System.Drawing.Size(82, 23);
            this.btnara.TabIndex = 3;
            this.btnara.Text = "Ara";
            this.btnara.UseVisualStyleBackColor = true;
            this.btnara.Click += new System.EventHandler(this.btnara_Click);
            // 
            // lblad
            // 
            this.lblad.AutoSize = true;
            this.lblad.Location = new System.Drawing.Point(346, 37);
            this.lblad.Name = "lblad";
            this.lblad.Size = new System.Drawing.Size(16, 16);
            this.lblad.TabIndex = 4;
            this.lblad.Text = "...";
            // 
            // lblsoyad
            // 
            this.lblsoyad.AutoSize = true;
            this.lblsoyad.Location = new System.Drawing.Point(346, 59);
            this.lblsoyad.Name = "lblsoyad";
            this.lblsoyad.Size = new System.Drawing.Size(16, 16);
            this.lblsoyad.TabIndex = 4;
            this.lblsoyad.Text = "...";
            // 
            // lblcinsiyet
            // 
            this.lblcinsiyet.AutoSize = true;
            this.lblcinsiyet.Location = new System.Drawing.Point(346, 84);
            this.lblcinsiyet.Name = "lblcinsiyet";
            this.lblcinsiyet.Size = new System.Drawing.Size(16, 16);
            this.lblcinsiyet.TabIndex = 4;
            this.lblcinsiyet.Text = "...";
            // 
            // lblmezuniyet
            // 
            this.lblmezuniyet.AutoSize = true;
            this.lblmezuniyet.Location = new System.Drawing.Point(346, 110);
            this.lblmezuniyet.Name = "lblmezuniyet";
            this.lblmezuniyet.Size = new System.Drawing.Size(16, 16);
            this.lblmezuniyet.TabIndex = 4;
            this.lblmezuniyet.Text = "...";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(552, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Doğum Tarihi:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // lbldgmtrh
            // 
            this.lbldgmtrh.AutoSize = true;
            this.lbldgmtrh.Location = new System.Drawing.Point(649, 37);
            this.lbldgmtrh.Name = "lbldgmtrh";
            this.lbldgmtrh.Size = new System.Drawing.Size(16, 16);
            this.lbldgmtrh.TabIndex = 4;
            this.lbldgmtrh.Text = "...";
            this.lbldgmtrh.Click += new System.EventHandler(this.label6_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(593, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 16);
            this.label6.TabIndex = 1;
            this.label6.Text = "Görevi:";
            this.label6.Click += new System.EventHandler(this.label5_Click);
            // 
            // lblgorev
            // 
            this.lblgorev.AutoSize = true;
            this.lblgorev.Location = new System.Drawing.Point(649, 59);
            this.lblgorev.Name = "lblgorev";
            this.lblgorev.Size = new System.Drawing.Size(16, 16);
            this.lblgorev.TabIndex = 4;
            this.lblgorev.Text = "...";
            this.lblgorev.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(569, 84);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "Görev Yeri:";
            this.label7.Click += new System.EventHandler(this.label5_Click);
            // 
            // lblmaas
            // 
            this.lblmaas.AutoSize = true;
            this.lblmaas.Location = new System.Drawing.Point(649, 110);
            this.lblmaas.Name = "lblmaas";
            this.lblmaas.Size = new System.Drawing.Size(16, 16);
            this.lblmaas.TabIndex = 4;
            this.lblmaas.Text = "...";
            this.lblmaas.Click += new System.EventHandler(this.label6_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(593, 110);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 16);
            this.label9.TabIndex = 1;
            this.label9.Text = "Maaşı:";
            this.label9.Click += new System.EventHandler(this.label5_Click);
            // 
            // lblgrvyri
            // 
            this.lblgrvyri.AutoSize = true;
            this.lblgrvyri.Location = new System.Drawing.Point(649, 84);
            this.lblgrvyri.Name = "lblgrvyri";
            this.lblgrvyri.Size = new System.Drawing.Size(16, 16);
            this.lblgrvyri.TabIndex = 4;
            this.lblgrvyri.Text = "...";
            this.lblgrvyri.Click += new System.EventHandler(this.label6_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(556, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 16);
            this.label8.TabIndex = 1;
            this.label8.Text = "Aktif Kullanıcı:";
            this.label8.Click += new System.EventHandler(this.label5_Click);
            // 
            // lblaktifkull
            // 
            this.lblaktifkull.AutoSize = true;
            this.lblaktifkull.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblaktifkull.Location = new System.Drawing.Point(649, 15);
            this.lblaktifkull.Name = "lblaktifkull";
            this.lblaktifkull.Size = new System.Drawing.Size(22, 22);
            this.lblaktifkull.TabIndex = 4;
            this.lblaktifkull.Text = "...";
            this.lblaktifkull.Click += new System.EventHandler(this.label6_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(198, 148);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 277);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1085, 353);
            this.dataGridView1.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(280, 135);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 16);
            this.label10.TabIndex = 1;
            this.label10.Text = "Rütbesi:";
            // 
            // lblrtb
            // 
            this.lblrtb.AutoSize = true;
            this.lblrtb.Location = new System.Drawing.Point(346, 135);
            this.lblrtb.Name = "lblrtb";
            this.lblrtb.Size = new System.Drawing.Size(16, 16);
            this.lblrtb.TabIndex = 4;
            this.lblrtb.Text = "...";
            // 
            // txttc
            // 
            this.txttc.Location = new System.Drawing.Point(349, 12);
            this.txttc.Name = "txttc";
            this.txttc.Size = new System.Drawing.Size(100, 22);
            this.txttc.TabIndex = 6;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1109, 639);
            this.Controls.Add(this.txttc);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblrtb);
            this.Controls.Add(this.lblmezuniyet);
            this.Controls.Add(this.lblcinsiyet);
            this.Controls.Add(this.lblsoyad);
            this.Controls.Add(this.lblgrvyri);
            this.Controls.Add(this.lblaktifkull);
            this.Controls.Add(this.lblmaas);
            this.Controls.Add(this.lblgorev);
            this.Controls.Add(this.lbldgmtrh);
            this.Controls.Add(this.lblad);
            this.Controls.Add(this.btnara);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblisim);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form3";
            this.Text = "Kullanıcı Veri Görünteleme Ekranı";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblisim;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnara;
        private System.Windows.Forms.Label lblad;
        private System.Windows.Forms.Label lblsoyad;
        private System.Windows.Forms.Label lblcinsiyet;
        private System.Windows.Forms.Label lblmezuniyet;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbldgmtrh;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblgorev;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblmaas;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblgrvyri;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblaktifkull;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblrtb;
        private System.Windows.Forms.MaskedTextBox txttc;
    }
}